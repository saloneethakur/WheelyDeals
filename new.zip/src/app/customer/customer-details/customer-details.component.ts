import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CustomerService } from 'src/app/customer-service.service';


@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit
{

  public constructor(public cusService:CustomerService,private route: ActivatedRoute){}
  public userId:any='';
  public obj:any[]=[];
  
  ngOnInit(): void 
  {
    this.userId = this.route.snapshot.paramMap.get('id');
    console.log(this.userId);
    this.loadCustomerDetails();
  }
  
  public loadCustomerDetails() 
  {
    this.obj = this.cusService.cusOb;
    console.log(this.obj);
     const user = this.obj.find(user => user.userId == this.userId);
      this.obj= (user);
     console.log(this.obj);
    console.log( typeof(this.obj));
  }
 
}
