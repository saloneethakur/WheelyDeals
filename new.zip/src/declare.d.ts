declare function counter():void;
declare function contentWayPoint():void;   